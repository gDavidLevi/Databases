CREATE VIEW [CarBrand] AS 
select
m.name_ru as Модель,
t.name_ru as Трансмиссия,
transport.price as Цена,
b.name_ru as Бренд
from Car c
inner join spr_Model m on c.model_id=m.id
inner join spr_Transmission t on c.transmission_id=t.id
inner join Transport transport on c.transport_id=transport.id
inner join spr_Brand b on transport.brand_id = b.id;

